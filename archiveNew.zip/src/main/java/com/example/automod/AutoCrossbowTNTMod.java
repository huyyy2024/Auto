package com.example.automod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.CrossbowItem;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class AutoCrossbowTNTMod implements ClientModInitializer {

    private static KeyBinding toggleKey;
    private static boolean enabled = false;

    // --- Trạng thái crossbow ---
    private boolean isCharging = false;

    // --- Chu kỳ đặt cart + châm lửa ---
    private int placeTick   = 0;
    private int flintTimer  = -1;
    private static final int PLACE_INTERVAL = 20; // đặt cart mỗi 1 giây
    private static final int FLINT_DELAY    = 4;  // tick chờ sau khi đặt cart

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.automod.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                "category.automod"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    // -----------------------------------------------------------------------
    private void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;

        // Toggle R
        while (toggleKey.wasPressed()) {
            enabled = !enabled;
            client.player.sendMessage(
                    Text.literal(enabled ? "§aAuto Mode: BẬT" : "§cAuto Mode: TẮT"), true);
            if (!enabled) reset(client);
        }

        if (!enabled) return;

        placeTick++;

        // 1) Đặt TNT minecart
        if (placeTick >= PLACE_INTERVAL) {
            placeTick = 0;
            if (placeMinecart(client)) {
                flintTimer = FLINT_DELAY;
            }
        }

        // 2) Châm lửa cart vừa đặt
        if (flintTimer > 0) {
            flintTimer--;
            if (flintTimer == 0) {
                flintTimer = -1;
                igniteNearbyCart(client);
            }
        }

        // 3) Bắn crossbow
        tickCrossbow(client);
    }

    // -----------------------------------------------------------------------
    // Đặt TNT minecart — nhìn thẳng xuống chân để đặt lên ray
    // -----------------------------------------------------------------------
    private boolean placeMinecart(MinecraftClient client) {
        int slot = findHotbar(client, Items.TNT_MINECART.getDefaultStack());
        if (slot < 0) {
            client.player.sendMessage(Text.literal("§cCần TNT Minecart trong hotbar!"), true);
            return false;
        }

        int prev = client.player.getInventory().selectedSlot;
        client.player.getInventory().selectedSlot = slot;

        float prevPitch = client.player.getPitch();
        client.player.setPitch(89f);

        client.interactionManager.interactItem(client.player, Hand.MAIN_HAND);

        client.player.setPitch(prevPitch);
        client.player.getInventory().selectedSlot = prev;
        return true;
    }

    // -----------------------------------------------------------------------
    // Châm lửa: tìm TntMinecartEntity gần nhất → right-click bằng flint&steel
    // -----------------------------------------------------------------------
    private void igniteNearbyCart(MinecraftClient client) {
        int flintSlot = findHotbar(client, Items.FLINT_AND_STEEL.getDefaultStack());
        if (flintSlot < 0) {
            client.player.sendMessage(Text.literal("§eCần Flint and Steel trong hotbar!"), true);
            return;
        }

        // Tìm cart trong vòng 5 block
        Vec3d pos = client.player.getPos();
        Box searchBox = Box.of(pos, 5, 5, 5);

        List<TntMinecartEntity> carts = client.world.getEntitiesByClass(
                TntMinecartEntity.class, searchBox, e -> !e.isRemoved());

        if (carts.isEmpty()) return;

        // Lấy cart gần nhất
        TntMinecartEntity target = carts.stream()
                .min((a, b) -> Double.compare(
                        a.squaredDistanceTo(client.player),
                        b.squaredDistanceTo(client.player)))
                .orElse(null);

        if (target == null) return;

        int prev = client.player.getInventory().selectedSlot;
        client.player.getInventory().selectedSlot = flintSlot;

        // Nhìn về phía cart
        aimAt(client, target.getPos().add(0, 0.5, 0));

        // Right-click entity
        EntityHitResult hitResult = new EntityHitResult(target);
        client.interactionManager.interactEntityAtLocation(
                client.player, target, hitResult, Hand.MAIN_HAND);

        client.player.getInventory().selectedSlot = prev;
    }

    // -----------------------------------------------------------------------
    // Bắn crossbow: nạp → bắn
    // -----------------------------------------------------------------------
    private void tickCrossbow(MinecraftClient client) {
        int slot = findCrossbow(client);
        if (slot < 0) {
            client.options.useKey.setPressed(false);
            isCharging = false;
            return;
        }

        client.player.getInventory().selectedSlot = slot;
        ItemStack stack = client.player.getInventory().getStack(slot);
        boolean charged = CrossbowItem.isCharged(stack);

        if (!charged) {
            isCharging = true;
            client.options.useKey.setPressed(true);
        } else {
            if (isCharging) {
                client.options.useKey.setPressed(false);
                isCharging = false;
            }
            client.interactionManager.interactItem(client.player, Hand.MAIN_HAND);
        }
    }

    // -----------------------------------------------------------------------
    // Hướng camera về một điểm (silent aim)
    // -----------------------------------------------------------------------
    private void aimAt(MinecraftClient client, Vec3d target) {
        Vec3d eyes = client.player.getEyePos();
        double dx = target.x - eyes.x;
        double dy = target.y - eyes.y;
        double dz = target.z - eyes.z;
        double horiz = Math.sqrt(dx * dx + dz * dz);

        float yaw   = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horiz));

        client.player.setYaw(yaw);
        client.player.setPitch(pitch);
    }

    // -----------------------------------------------------------------------
    // Tìm crossbow trong hotbar (ưu tiên đã nạp đạn)
    // -----------------------------------------------------------------------
    private int findCrossbow(MinecraftClient client) {
        PlayerInventory inv = client.player.getInventory();
        int charged = -1, any = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack s = inv.getStack(i);
            if (s.getItem() == Items.CROSSBOW) {
                if (CrossbowItem.isCharged(s)) { charged = i; break; }
                else if (any < 0) any = i;
            }
        }
        return charged >= 0 ? charged : any;
    }

    // -----------------------------------------------------------------------
    // Tìm item trong hotbar theo item type
    // -----------------------------------------------------------------------
    private int findHotbar(MinecraftClient client, ItemStack target) {
        PlayerInventory inv = client.player.getInventory();
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).getItem() == target.getItem()) return i;
        }
        return -1;
    }

    // -----------------------------------------------------------------------
    private void reset(MinecraftClient client) {
        client.options.useKey.setPressed(false);
        isCharging = false;
        placeTick  = 0;
        flintTimer = -1;
    }
}
